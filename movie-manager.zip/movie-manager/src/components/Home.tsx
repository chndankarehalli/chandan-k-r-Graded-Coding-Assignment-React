const Home = () => {
    return (
      <section className="hero-section">
        <div className="heading">
          <p>Movies on the Tip</p>
        </div>
      </section>
    );
  };
  
  export default Home;